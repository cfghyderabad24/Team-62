package assignment05.bootcamp.team62

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    lateinit var recyclerView: RecyclerView
    lateinit var searchBr: SearchView

    lateinit var recyclerAdapter1: RecyclerAdapter1

    lateinit var mainViewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        mainViewModel = ViewModelProvider(this, object: ViewModelProvider.Factory{
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return MainViewModel(this@MainActivity) as T
            }
        }).get(MainViewModel::class.java)

        recyclerView = findViewById(R.id.recycler)
        searchBr = findViewById(R.id.searchBar)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerAdapter1 = RecyclerAdapter1(mainViewModel.compList)
        recyclerView.adapter = recyclerAdapter1

        searchBr.setOnQueryTextListener(object: SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean {
                if(!query.isNullOrEmpty()){
                    val tempList = mainViewModel.compList.filter {
                        it.companyName.contains(query,ignoreCase = true) ||
                                it.year.contains(query,ignoreCase = true) ||
                                it.csrPolicies.any{policy-> policy.contains(query,ignoreCase = true)} ||
                        it.geographicsOfInterest.any{locations-> locations.contains(query,ignoreCase = true)}
                    }
                    recyclerView.adapter = RecyclerAdapter1(tempList)
                }
                return true
            }

            override fun onQueryTextChange(query: String?): Boolean {
                if(!query.isNullOrEmpty()){
                    val tempList = mainViewModel.compList.filter {
                        it.companyName.contains(query,ignoreCase = true) ||
                                it.year.contains(query,ignoreCase = true) ||
                                it.csrPolicies.any{policy-> policy.contains(query,ignoreCase = true)} ||
                                it.geographicsOfInterest.any{locations-> locations.contains(query,ignoreCase = true)}
                    }
                    recyclerView.adapter = RecyclerAdapter1(tempList)
                }
                return true
            }
        })

    }
}