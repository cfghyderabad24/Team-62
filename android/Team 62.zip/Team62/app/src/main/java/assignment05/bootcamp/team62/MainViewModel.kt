package assignment05.bootcamp.team62

import android.content.Context
import androidx.lifecycle.ViewModel
import com.google.gson.Gson

class MainViewModel(private val context: Context): ViewModel() {
    lateinit var compList : List<Company>

    init {
        getList()
    }

    fun getList(){
        val inputStream = context.assets.open("data.json")
        val byteArray = ByteArray(inputStream.available())
        inputStream.read(byteArray)
        inputStream.close()

        val json = String(byteArray, Charsets.UTF_8)
        compList =  Gson().fromJson(json, Array<Company>::class.java).toList()
    }
}


data class Company(
    val companyName: String,
    val year: String,
    val totalTurnover: Double,
    val netWorth: Double,
    val isMandatedByLaw: Boolean,
    val csrPolicies: List<String>,
    val annualCsrSpend :Double,
    val unspentCsr: Double,
    val methodOfExecution : List<String>,
    val geographicsOfInterest: List<String>
)