package assignment05.bootcamp.team62

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecyclerAdapter1(private var compList: List<Company>): RecyclerView.Adapter<RecyclerAdapter1.RecyclerViewHolder1>(){
    class RecyclerViewHolder1(view : View): RecyclerView.ViewHolder(view){
        val compName = view.findViewById<TextView>(R.id.compName)
        val compYear = view.findViewById<TextView>(R.id.compYear)
        val compCSRspend = view.findViewById<TextView>(R.id.compCSRspend)
        val compPolicies = view.findViewById<TextView>(R.id.compPolicies)
        val compLocations = view.findViewById<TextView>(R.id.compLocation)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerViewHolder1 {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_single,parent, false)
        return RecyclerViewHolder1(view)
    }

    override fun getItemCount(): Int {
        return compList.size
    }

    override fun onBindViewHolder(holder: RecyclerViewHolder1, position: Int) {
        val item = compList[position]

        holder.compName.text = item.companyName
        holder.compYear.text = "Year: " + item.year
        holder.compCSRspend.text = "CSR spend:" + item.annualCsrSpend.toString()

        val csrPolicies = ("Policies: " +
                item.csrPolicies?.joinToString(separator = "\n")) ?: ""
        holder.compPolicies.text = csrPolicies

        val compLoc =
            ("Locations: " + item.geographicsOfInterest?.joinToString(separator = "\n")) ?: ""
        holder.compLocations.text = compLoc
    }
}